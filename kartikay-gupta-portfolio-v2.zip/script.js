/* ==========================================================================
   KARTIKAY GUPTA - MULTI-PAGE ROUTER, ANIMATIONS & STUDENT TOOLS ENGINE
   ========================================================================== */

window.portfolioV2Loaded = true;

// 1. MULTI-PAGE NAVIGATION ENGINE (Works as SPA & Multi-File)
function switchPage(pageId) {
  const sections = document.querySelectorAll('.page-section');
  sections.forEach(sec => sec.classList.remove('active'));

  const target = document.getElementById('page-' + pageId);
  if (target) {
    target.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  const links = document.querySelectorAll('.nav-links a[data-page]');
  links.forEach(link => {
    link.classList.toggle('active-page', link.getAttribute('data-page') === pageId);
  });

  if (pageId === 'academics') {
    animateSkillBars();
  }
}

// 2. THEME SWITCHER
function setTheme(themeName, btnEl) {
  document.documentElement.setAttribute('data-theme', themeName);
  localStorage.setItem('kg_portfolio_theme', themeName);
  if (btnEl) {
    document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));
    btnEl.classList.add('active');
  }
}

// 3. ANIMATED SKILL BARS
function animateSkillBars() {
  const fills = document.querySelectorAll('.progress-fill');
  fills.forEach(fill => {
    const width = fill.getAttribute('data-width') || '85%';
    fill.style.width = '0%';
    setTimeout(() => {
      fill.style.width = width;
    }, 120);
  });
}

// 4. 3D ID CARD FLIP
function flipIdCard() {
  const card = document.getElementById('idCardInner');
  if (card) card.classList.toggle('flipped');
}

// 5. PROJECT CATEGORY FILTER
function filterProjects(category, btnEl) {
  if (btnEl) {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btnEl.classList.add('active');
  }
  const cards = document.querySelectorAll('.project-item');
  cards.forEach(card => {
    const cat = card.getAttribute('data-category');
    if (category === 'all' || cat === category) {
      card.style.display = 'flex';
    } else {
      card.style.display = 'none';
    }
  });
}

// 6. C CODE VIEWER MODAL
const codeSnippets = {
  student_record: `// Student Record Management System in C
// Author: Kartikay Gupta (A2026CSE12753) - Section D (CSE 4)
#include <stdio.h>
#include <string.h>

struct Student {
    char id[20];
    char name[50];
    char section[15];
    float sgpa;
};

int main() {
    struct Student s1 = {"A2026CSE12753", "Kartikay Gupta", "Section D (CSE 4)", 9.2};
    printf("=== IMS ENGINEERING COLLEGE GHAZIABAD ===\n");
    printf("Student Name : %s\n", s1.name);
    printf("College ID   : %s\n", s1.id);
    printf("Section      : %s\n", s1.section);
    printf("Target SGPA  : %.2f\n", s1.sgpa);
    return 0;
}`,
  matrix_calc: `// 2D Matrix Addition & Transpose in C (1st Year PPS Lab)
// Author: Kartikay Gupta (A2026CSE12753)
#include <stdio.h>

int main() {
    int a[2][2] = {{4, 7}, {2, 9}}, b[2][2] = {{1, 3}, {5, 6}}, sum[2][2];
    printf("Matrix Addition Result:\n");
    for(int i = 0; i < 2; i++) {
        for(int j = 0; j < 2; j++) {
            sum[i][j] = a[i][j] + b[i][j];
            printf("%d\t", sum[i][j]);
        }
        printf("\n");
    }
    return 0;
}`
};

function openCodeModal(key, title) {
  const modal = document.getElementById('codeModal');
  const titleEl = document.getElementById('modalTitle');
  const codeEl = document.getElementById('modalCode');
  if (modal && titleEl && codeEl) {
    titleEl.textContent = title;
    codeEl.textContent = codeSnippets[key] || '';
    modal.classList.add('open');
  }
}

function closeCodeModal() {
  const modal = document.getElementById('codeModal');
  if (modal) modal.classList.remove('open');
}

// 7. LIVE TOOL 1: 75% ATTENDANCE CALCULATOR
function calculateAttendance() {
  const attended = parseFloat(document.getElementById('att-attended').value);
  const total = parseFloat(document.getElementById('att-total').value);
  const out = document.getElementById('att-result');

  if (isNaN(attended) || isNaN(total) || total <= 0 || attended < 0 || attended > total) {
    out.innerHTML = '<span style="color: var(--danger);">Please enter valid class numbers (Attended ≤ Total).</span>';
    return;
  }

  const pct = ((attended / total) * 100).toFixed(2);
  if (pct >= 75) {
    const bunkable = Math.floor((attended - 0.75 * total) / 0.75);
    out.innerHTML = `<span style="color: var(--success);">Current Attendance: ${pct}% ✅</span><br>You are above the 75% criteria! You can safely miss up to <strong>${bunkable}</strong> upcoming classes.`;
  } else {
    const needed = Math.ceil((0.75 * total - attended) / 0.25);
    out.innerHTML = `<span style="color: var(--warning);">Current Attendance: ${pct}% ⚠️</span><br>You need to attend the next <strong>${needed}</strong> consecutive classes to reach 75%.`;
  }
}

// 8. LIVE TOOL 2: SGPA PREDICTOR
function calculateSGPA() {
  const pps = parseFloat(document.getElementById('grade-pps').value) || 0;
  const math = parseFloat(document.getElementById('grade-math').value) || 0;
  const phy = parseFloat(document.getElementById('grade-phy').value) || 0;
  const elec = parseFloat(document.getElementById('grade-elec').value) || 0;
  // Standard credit weights: Math(4), Physics(4), PPS(3), Electrical/Labs(4)
  const totalWeighted = (math * 4) + (phy * 4) + (pps * 3) + (elec * 4);
  const sgpa = (totalWeighted / 15).toFixed(2);
  const out = document.getElementById('sgpa-result');
  out.innerHTML = `Predicted Semester SGPA: <strong style="color: var(--primary); font-size: 1.2rem;">${sgpa} / 10.0</strong>`;
}

// 9. LIVE TOOL 3: NUMBER SYSTEM CONVERTER (DEC / BIN / HEX / OCT)
function convertNumber() {
  const val = parseInt(document.getElementById('num-dec').value, 10);
  const out = document.getElementById('num-result');
  if (isNaN(val)) {
    out.innerHTML = 'Enter a valid decimal integer above.';
    return;
  }
  out.innerHTML = `
    <div><strong>Binary (Base 2):</strong> <span style="color:var(--primary)">${val.toString(2)}</span></div>
    <div><strong>Octal (Base 8):</strong> <span style="color:var(--accent)">${val.toString(8)}</span></div>
    <div><strong>Hexadecimal (Base 16):</strong> <span style="color:var(--success)">0x${val.toString(16).toUpperCase()}</span></div>
  `;
}

// 10. COPY EMAIL & SEND QUICK MESSAGE
function copyEmail() {
  navigator.clipboard.writeText("kartikaygupta0139@gmail.com");
  alert("Copied Email: kartikaygupta0139@gmail.com");
}

function sendQuickMail(e) {
  e.preventDefault();
  const name = document.getElementById('msg-name').value || 'Visitor';
  const body = document.getElementById('msg-body').value || 'Hi Kartikay, I viewed your portfolio!';
  window.location.href = `mailto:kartikaygupta0139@gmail.com?subject=Portfolio Contact from ${encodeURIComponent(name)}&body=${encodeURIComponent(body)}`;
}

// 11. BACKGROUND PARTICLE / MATRIX ANIMATION ENGINE
let bgMode = 'particles';
function setBgMode(mode, btnEl) {
  bgMode = mode;
  if (btnEl) {
    document.querySelectorAll('.bg-btn').forEach(b => b.classList.remove('active'));
    btnEl.classList.add('active');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  // Typing Effect
  const roles = [
    "B.Tech CSE (1st Year) @ IMSEC Ghaziabad",
    "Section D (CSE 4) • ID: A2026CSE12753",
    "C Programmer & Frontend Web Developer",
    "Building Interactive Tools & Clean UI"
  ];
  let rIdx = 0, cIdx = 0, isDel = false;
  const typeEl = document.getElementById('typing-text');

  function runTyping() {
    if (!typeEl) return;
    const curr = roles[rIdx];
    typeEl.textContent = curr.substring(0, cIdx) + " |";
    if (!isDel && cIdx < curr.length) {
      cIdx++;
      setTimeout(runTyping, 50);
    } else if (isDel && cIdx > 0) {
      cIdx--;
      setTimeout(runTyping, 28);
    } else {
      isDel = !isDel;
      if (!isDel) rIdx = (rIdx + 1) % roles.length;
      setTimeout(runTyping, isDel ? 1500 : 250);
    }
  }
  runTyping();
  animateSkillBars();

  // Canvas Particles
  const canvas = document.getElementById('bg-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let w = canvas.width = window.innerWidth;
  let h = canvas.height = window.innerHeight;

  window.addEventListener('resize', () => {
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
  });

  const pts = Array.from({ length: 48 }, () => ({
    x: Math.random() * w,
    y: Math.random() * h,
    vx: (Math.random() - 0.5) * 0.7,
    vy: (Math.random() - 0.5) * 0.7,
    r: Math.random() * 2 + 1
  }));

  function drawBg() {
    ctx.clearRect(0, 0, w, h);
    if (bgMode === 'off') {
      requestAnimationFrame(drawBg);
      return;
    }

    ctx.fillStyle = 'rgba(56, 189, 248, 0.45)';
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';

    for (let i = 0; i < pts.length; i++) {
      let p = pts[i];
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0 || p.x > w) p.vx *= -1;
      if (p.y < 0 || p.y > h) p.vy *= -1;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();

      if (bgMode === 'particles') {
        for (let j = i + 1; j < pts.length; j++) {
          let p2 = pts[j];
          let dist = Math.hypot(p.x - p2.x, p.y - p2.y);
          if (dist < 130) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      }
    }
    requestAnimationFrame(drawBg);
  }
  drawBg();
});
