========================================================================
KARTIKAY GUPTA - MULTI-PAGE ANIMATED PORTFOLIO (VERSION 2.0)
========================================================================
Student Name : Kartikay Gupta
College ID   : A2026CSE12753
Course       : B.Tech CSE (1st Year)
Section      : Section D (CSE 4)
College      : IMS Engineering College, Ghaziabad
Email        : kartikaygupta0139@gmail.com
Contact      : +91 9023380428

WHAT'S NEW IN VERSION 2.0:
1. 5 FULL PAGES (Hybrid Multi-Page + Instant SPA Router):
   - index.html     : Home & 3D Flip Student Identity Card
   - academics.html : Animated Skill Progress Bars & 1st-Year CSE Coursework
   - projects.html  : Category Filter + Live C Source Code Modal Viewer
   - tools.html     : 3 Working Student Calculators (75% Attendance Tracker,
                      Semester SGPA Predictor, Decimal/Binary/Hex Converter)
   - contact.html   : Quick Email Composer, Directory Card & Print Button

2. ANIMATIONS & VISUAL OPTIONS:
   - Interactive HTML5 Canvas Background (Neural Nodes, Floating Stars, or Off)
   - 4 Live Color Themes (Cyber Blue, Matrix Hacker, Royal Aurora, Daylight)
   - 3D Flip Animation on the Student Academic ID Card
   - Smooth Keyframe Page Transitions & Animated Skill Meters
========================================================================
